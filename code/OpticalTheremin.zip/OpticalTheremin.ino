#include <Adafruit_VL6180X.h>
#include <Wire.h>
#include <driver/i2s.h>
#include <math.h>

#define I2S_PORT I2S_NUM_0

// Audio parameters
#define SAMPLE_RATE 44100
#define AMP_MIN 10  
#define MIN 55
#define 


#define BUFFER_LEN 256

#define scl_pin 17
#define sda_pin 18;
#define lrc 4,
#define bclk 2
#deifne dout 1
#define vol_pin 5;
#define vibrato_pin 8;
#define sensitivity_pin 16;

Adafruit_VL6180X sensor;



int16_t samples[BUFFER_LEN];


void setup() {
    Wire.setPins(scl_pin, sda_pin);
    sensor = Adafruit_VL6180X();
    sensor.begin();
    i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = BUFFER_LEN,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };
   i2s_pin_config_t pin_config = {
    .bck_io_num = bclk,
    .ws_io_num = lrc,
    .data_out_num = dout,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);
  i2s_set_pin(I2S_PORT, &pin_config);
}

void loop() {
    checkError();
    play(toTone(sensor.readRange()));
}

int16_t toTone(int16_t value){
  return (int16_t)(6.61333*value+MIN)

}

void play(int16_t freq){
  static float phase = 0.0;
  const float phaseIncrement = 2.0 * PI * freq / SAMPLE_RATE;

  for (int i = 0; i < BUFFER_LEN; i++) {
    int16_t sound = (int16_t)(AMPLITUDE * sin(phase));
    int16_t silence = 0;

    samples[2 * i] = (LEFT) ? sound : silence;       // Left channel
    samples[2 * i + 1] = (RIGHT) ? sound : silence;  // Right channel

    phase += phaseIncrement;
    if (phase >= 2.0 * PI) phase -= 2.0 * PI;
  }

  size_t bytes_written;
  i2s_write(I2S_PORT, samples, sizeof(samples), &bytes_written, portMAX_DELAY);
}
  
void checkError(){
  uint8_t status = sensor.readRangeStatus();
  if  ((status >= VL6180X_ERROR_SYSERR_1) && (status <= VL6180X_ERROR_SYSERR_5)) {
    Serial.println("System error");
  }
  else if (status == VL6180X_ERROR_ECEFAIL) {
    Serial.println("ECE failure");
  }
  else if (status == VL6180X_ERROR_NOCONVERGE) {
    Serial.println("No convergence");
  }
  else if (status == VL6180X_ERROR_RANGEIGNORE) {
    Serial.println("Ignoring range");
  }
  else if (status == VL6180X_ERROR_SNR) {
    Serial.println("Signal/Noise error");
  }
  else if (status == VL6180X_ERROR_RAWUFLOW) {
    Serial.println("Raw reading underflow");
  }
  else if (status == VL6180X_ERROR_RAWOFLOW) {
    Serial.println("Raw reading overflow");
  }
  else if (status == VL6180X_ERROR_RANGEUFLOW) {
    Serial.println("Range reading underflow");
  }
  else if (status == VL6180X_ERROR_RANGEOFLOW) {
    Serial.println("Range reading overflow");
  }
  
}
